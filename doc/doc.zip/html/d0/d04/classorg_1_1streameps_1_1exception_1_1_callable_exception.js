var classorg_1_1streameps_1_1exception_1_1_callable_exception =
[
    [ "CallableException", "d0/d04/classorg_1_1streameps_1_1exception_1_1_callable_exception.html#ab0e7259d18f17f0fc4d2d9c103cea65e", null ],
    [ "setMessage", "d0/d04/classorg_1_1streameps_1_1exception_1_1_callable_exception.html#a48bb54f5ece3218a17f2e4f86f9794f0", null ]
];