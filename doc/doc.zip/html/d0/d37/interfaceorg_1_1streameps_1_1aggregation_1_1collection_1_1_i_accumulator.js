var interfaceorg_1_1streameps_1_1aggregation_1_1collection_1_1_i_accumulator =
[
    [ "getIdentifier", "d0/d37/interfaceorg_1_1streameps_1_1aggregation_1_1collection_1_1_i_accumulator.html#a5e78622f9f0be4c13f62317ba2111562", null ],
    [ "getSizeCount", "d0/d37/interfaceorg_1_1streameps_1_1aggregation_1_1collection_1_1_i_accumulator.html#acc5157c9d07295f0db359832a93b4f6b", null ],
    [ "setIdentifier", "d0/d37/interfaceorg_1_1streameps_1_1aggregation_1_1collection_1_1_i_accumulator.html#a5a3b19ad8d494bd8349b82e3b07888c7", null ]
];